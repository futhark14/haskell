
## Date  Time Work

## 17-feb 2h  
Deciding project, research about scalpel and scraping, meeting
## 18-feb	7h	
Planning and discussion around work effort/communication and research about scalpel, trying to grasp github, meeting
## 19-feb	4h	
Research on scalpel, scraping and implementation, meeting
## 20-feb	2h 
Webdriver, java development kit, selenium research. Nothing was usable, continued research on scalpel
## 21-feb	6h	
Attempts to understand scalpel documentation, navigate through HTML code, attempting scrapin -> success!!!, co-working
## 22-feb 2h
Starting to structure report
## 23-feb	3h	
Coding, writing report, research, meeting
## 25-feb	1h
TA meeting, issues found, writing report
## 26-feb	2h
structuring work plan/problems, attempted coding, research, meeting
## 27-feb 3h 
coding, structuring/writing report
## 28-feb 3h 
coding, writing report, meeting and discussion on how to proceed
## 01-mar 7h 
coding, writing report, meeting
## 02-mar 4h 
finalizing code and report, TA meeting, meeting
## 03-mar 5h  
fine touching code and report
## 04-mar 6h
finalizing, meeting
