## Project diary, Felix Agnerdahl

## 17/2, 2h
Meeting, we came up with ideas and planned the project. 
Research about web-scraping and scalpel.

## 18/2, 10h
Had issues with cabal and spent a long time getting it to work again. 
Getting scalpel to properly import. More research on web-scraping. 
A long night of understanding git and github. Learning how to use github in vscode.

## 19/2, 3h
Had a meeting and got github working.
Planned what the next step is.
Research on web-scraping.

## 20/2, 3h
Trying to understand the scalpel library.

## 21/2, 6h
Worked mostly in group but alone for a while as well. 
Worked on extracting the current value of any stock on yahoo financial.

## 22/2, 6h
Created functions that scrape the historical prices of any stock on finance.yahoo.com, the past five days, weeks and months.

## 23/2, 4h
Wrote functions descriptions.
Had a meeting and worked together to make a few functions.
More function descriptions.

## 25/2, 1h
First TA meeting.
Encountered some issues with the functions that take the historical prices.

## 26/2, 2h
Meeting, decided what to focus on and how to proceed.

## 27/2, 45 min
Looking over report.

## 28/2, 3h 30min
Group discussion and working out some issues with a few functions.
Worked on a few functions.

## 1/3, 9h
Meeting.
Created functions and implemented them in the main function.

## 2/3, 5h 30min
Meeting with TA and group meeting. Cleaning up files. A few additions to the main function. Function descriptions. Edits and additions to the report.

## 3/3, 6h 30min
Proof reading the report and the function descriptions. Adding and removing bits of text. Writing on the report.

## 4/3, 6h
Team worked together to finalize everything.
