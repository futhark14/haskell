## Project Diary - Lukas Lindén Thöming

## 17-02-2021 - Discussion with group members, decision about what the project will be. (2 hours)

## 18-02-2021 - Group meeting and discussion. Researching github, scraping (scalpel library). Discussed general planning. (7 hours)

## 19-02-2021 - Reading up on libraries and concepts that are to be used for the project (an hour)
##            - Researching web scraping, the scalpel library and how to implement it. (4 hours) 

## 21-02-2021 - Working together trying to create a scraping function. Large amount of time personally spent troubleshooting type errors. (8 hours)

## 22-02-2021 - Initial work on the project report (2 hours)

## 23-02-2021 - Discussion with group members on how to develop the project further. Started designing a function that tries to tell if a stock is viable (buy or sell). (3 hours)

## 24-02-2021 - Zoom-meeting with supervisor (15 minutes)

## 25-02-2021 - Further work alone on the buy or sell function, trying to extrapolate high and low points from the stock chart. (1.5 hours)

## 26-02-2021 - Group discussion about a bug affecting the monthly and weekly stock viewing functions. Discussed fibonacci retracement for evaluating stock viability. (2 hours) 

## 27-02-2021 - Discussed code, and coding (2.5 hours)

## 28-02-2021 - Further group discussion and collaboration. Researched fibonacci retracement. Planned general structure of the fibonacci retracement function (which indicates buy and sell opportunities). Currently solving the issue of getting the correct high and low values from a stock. (about 4 hours)

## 01-02-2021 - Finished a working fibonacci retracement function that attemps to predict stock movement, based on data from the past few days. (4.5 hours)
##              Additions to the report about shortcomings of the fibonacci retracement function (10 minutes).

## 02-02-2021 - Finishing touches, improved naming of functions. Meeting on Zoom with supervisor. (4 hours).
##              Proofreading report, checking code for improvements (alone). (1.5 hours)

## 03-03-2021 - Proofreading report further. Checking through all of the code. Discussed small changes and issues with group (3 hours)

## 04-03-2021 - Work with group, getting final version ready for turn in. (6 hours)
