# Group 24

Work & Communication

Where, and how often will you meet while working?
Meetings will be held 3-4 times a week, or when unexpected things happen. These meetings will occur over discord.


How do you communicate in the group - what channels? - when?
Communication will mainly be through a discord server. Whenever an issue is encountered, someone comes up with a new idea and when we have our meetings.


How will you use other tools, like trello or git?
Github will be used, updated whenever progress is made.


How do you coordinate the final hand-in?
All group members will overlook each group members parts, to ensure everyone is on the same terms and understands what has been written.


How do you ensure everyone knows what they should do after their current task, and what everyone else is working on?
To ensure that everyone knows what to do after tasks, we will assign tasks beyond the current task


Surprises

What should you do if somebody feels left outside?
With regular meetings and involving the whole group in decisions this should be preventable. On the off chance of someone still feeling left out we will have to talk about it and come up with a solution.

What should you do if someone gets stuck on their current task?
Help each other out and cooperate.

What happens if someone feels another person isn’t doing their fair share?
Speak up, or note to another person within the group so it can be discussed.

What happens if someone is not communicating in the manner or frequency agreed upon?
That person has to be noted of it
